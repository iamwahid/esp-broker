#include <stdio.h>
#include <WString.h>

#include "_Helper.h"

String macStr(uint8_t * addr) {
  char macStr[18];

  snprintf(macStr, sizeof(macStr), "%02X:%02X:%02X:%02X:%02X:%02X",
         addr[0], addr[1], addr[2], addr[3], addr[4], addr[5]);
  return macStr;
}

void macHex(uint8_t * dst, char * str) {
  char* ptr;

  dst[0] = strtol(str, &ptr, 16 );
  for( uint8_t i = 1; i < 6; i++ )
  {
    dst[i] = strtol(ptr+1, &ptr, 16 );
  }
  // DEBUG
  // Serial.print(dst[0], 16);
  // for( uint8_t i = 1; i < 6; i++)
  // {
  //   Serial.print(':');
  //   Serial.print( dst[i], 16);
  // }
    // Serial.println();
  // Serial.println(str);
}