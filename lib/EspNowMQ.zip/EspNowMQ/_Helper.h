#ifndef __HELPER_H_
#define __HELPER_H_

String macStr(uint8_t * addr);

void macHex(uint8_t * dst, char * str);

#endif