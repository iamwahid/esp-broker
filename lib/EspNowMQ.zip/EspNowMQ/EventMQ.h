#ifndef EVENT_MQ_H
#define EVENT_MQ_H

#include "_Defs.h"
#include "EspNowMQ.h"
#include <Ticker.h>
#include <set>
#include <vector>

struct LogicObject {
  int value = 0;
  LogicObject() {};
  LogicObject(int value): value(value) {}
  virtual ~LogicObject() {};

  int &getValue() { return value;}
  void updateObject() {

  }
};

enum RUN_TYPE: uint8_t {
  ONCE,
  PERIODIC
};

struct EventObject {
  String event_name;

  MessageObject rx_Msg;
  
  bool enabled = true;

  EspNowMQPeerInfo plain;

  EventObject() {};
  EventObject(String name): event_name(name) {};
  
  virtual ~EventObject() {};

	virtual bool isEnabled() { return enabled; }

  virtual bool hasListener(uint8_t * mac) {return false;};
  virtual bool addListener(EspNowMQPeerInfo &listener, ListenerRole role) {return false;};
  virtual bool addListener(int pos, ListenerRole role) {return false;};
  virtual bool removeListener(uint8_t * mac) {return false;};
  virtual EspNowMQPeerInfo &getListener(uint8_t * mac) {
    return plain;
  };

  virtual void process(const uint8_t* data, uint8_t size) {
    memcpy(&rx_Msg, data, sizeof(rx_Msg));
    run();
  };

  virtual void run() {
#if defined(ARDUINO_ARCH_ESP32)
  Serial.print(":: Task running on core ");
  Serial.print(xPortGetCoreID());
  Serial.println(" ::    ");
#endif
  }

};

struct EventBrokerObject : EventObject {
  std::map<String, std::shared_ptr<EspNowMQPeerInfo>> listenerMap;

  std::set<String> pubSet = {};
  std::set<String> subSet = {};

  MessageObject result;
  int listenerCount = 0;
  const static int MAX_PEERS = 20;

  bool repeating = false;

  uint8_t runType = RUN_TYPE::ONCE;
  Ticker tickr;

  EventBrokerObject(): EventObject() {};
  EventBrokerObject(String name): EventObject(name) {};
  
  virtual ~EventBrokerObject() {};

  bool hasListener(uint8_t * mac) override;
  bool addListener(EspNowMQPeerInfo &listener, ListenerRole role) override;
  bool addListener(int pos, ListenerRole role) override;
  bool addPublisher(EspNowMQPeerInfo &listener);
  bool addSubscriber(EspNowMQPeerInfo &listener);
  bool removeListener(uint8_t * mac) override;
  EspNowMQPeerInfo &getListener(uint8_t * mac) override;

  bool updateData(uint8_t * mac, DataObject &data, bool setResult = true);

  bool isEqual(EspNowMQPeerInfo &peer);

  virtual void logical() {};

  virtual void preProcess() {};

  virtual bool postProcess(EspNowMQPeerInfo &peer, MessageObject &msg) {
		// logical();
		return true;
	}


	virtual bool isEnabled() { return enabled; }

  void process(const uint8_t* data, uint8_t size) override;
  void run() override;
  
  void repeat(uint32_t time = 1000);

  void once(uint32_t time = 1000);

  void pause(); 

  void retoggle(uint32_t time = 1000);

  private:
  static void sRun(EventBrokerObject * evObj);
};

extern std::map<String, std::shared_ptr<EventObject>> eventMap;
extern std::map<String, esp_rc_event_t> eventRCMap;

#endif