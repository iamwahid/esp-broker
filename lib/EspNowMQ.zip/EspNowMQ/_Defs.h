#ifndef __DEFS_H_
#define __DEFS_H_

#include <map>
#include <memory>
#include <WString.h>
#include <cstddef>
#include <cstdint>

typedef std::function<void(void)> esp_rc_callback_t;
typedef std::function<void(const uint8_t *, uint8_t)> esp_rc_data_callback_t;
typedef std::function<void(uint8_t mac[6], uint8_t* buf, size_t count, void* cbarg)> esp_rx_cb_t;

/** @brief Key length. */
static const int ESPNOW_MQ_KEYLEN = 16;

/** @brief Maximum message length. */
static const int ESPNOW_MQ_MAXMSGLEN = 200; // esp8266 max len

/** @brief Listener/Peer Status. */
enum class ListenerStatus : uint8_t {
  OFFLINE = 0, 
  ONLINE  = 1, 
  BUSY    = 2,
};

/** @brief Result of send operation. */
enum class EspNowMQSendStatus : uint8_t {
  NONE = 0, ///< result unknown, send in progress
  OK   = 1, ///< sent successfully
  FAIL = 2, ///< sending failed
};

/** @brief Listener/Peer Type. */
enum class ListenerType : uint8_t {
  UNKNOWN = 0,
  INPUT_BINARY = 1,
  INPUT_ANALOG = 2,
  OUTPUT_BINARY = 3,
  OUTPUT_ANALOG = 4,
};

enum ListenerRole : uint8_t {
	PUB = 0,
	SUB = 1
};

struct DataObject {
	String name;
	float value = 0.0;
	DataObject() {};

	DataObject(String name, float value): name(name), value(value) {};

	DataObject(const DataObject& data): name(data.name), value(data.value) {};
};

struct EspNowMQPeerInfo {
  uint8_t mac[6];
  uint8_t channel;
	ListenerStatus status;
	ListenerType type;
	String listenOn; // event
	ListenerRole role;
	DataObject data;

	EspNowMQPeerInfo() {}
	EspNowMQPeerInfo(EspNowMQPeerInfo & peer) {
		memcpy(mac, peer.mac, 6);
		channel = peer.channel;
		status = peer.status;
		type = peer.type;
		listenOn = peer.listenOn;
		role = peer.role;
		data = peer.data;
	}
};

struct MessageObject {
	String m_event_name;
  uint8_t dst[6];
  uint8_t src[6];
	bool confirm = false;
	DataObject data;
};

struct esp_rc_event_t {
	String event_name;
	esp_rc_callback_t on_cb;
	esp_rc_data_callback_t on_data_cb;
};

#endif